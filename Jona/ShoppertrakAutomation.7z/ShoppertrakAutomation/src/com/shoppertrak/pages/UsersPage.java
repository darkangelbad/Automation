package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UsersPage {

    	private static WebElement element = null;
	
	
	public static WebElement btn_Find(WebDriver driver)
	{
		element = driver.findElement(By.id("searchButton"));
		return element;
	}
	
	public static WebElement btn_Logout(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Log Out"));
		return element;
	}	
	
	public static WebElement btn_Sites(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Sites"));
		return element;
	}
	
	public static WebElement btn_Orgs(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Organizations"));
		return element;
	}
	
	public static WebElement btn_Dash(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Dashboards"));
		return element;
	}
	
	public static WebElement btn_UserSubmit(WebDriver driver)
	{
		element = driver.findElement(By.id("submitButton"));
		return element;
	}
	
	public static WebElement lbl_Changes(WebDriver driver)
	{
		element = driver.findElement(By.id("//*[@id='usersForm']/div/div[1]/span"));
		return element;
	}
	
	public static WebElement opt_UserAdmin(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions0.enabled1"));
		return element;
	}
	
	public static WebElement opt_SiteCommunication(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions1.enabled1"));
		return element;
	}
	
	public static WebElement opt_DataManager(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions0.enabled2"));
		return element;
	}
	
	public static WebElement opt_DataExtractAPISettings(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions3.enabled1"));
		return element;
	}
	
	public static WebElement opt_InstallationGroup(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions4.enabled1"));
		return element;
	}
	
	public static WebElement opt_KPIOutbound(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions5.enabled1"));
		return element;
	}
	
	public static WebElement opt_TrafficReportAPI(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions6.enabled1"));
		return element;
	}
	
	public static WebElement opt_TrafficReportConfig(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions7.enabled1"));
		return element;
	}
	
	public static WebElement opt_LoadOperatingHours(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions8.enabled1"));
		return element;
	}
	
	public static WebElement opt_CustomerAccess(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions9.enabled1"));
		return element;
	}
	
	public static WebElement opt_AdvancedConfigurationUser(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions10.enabled1"));
		return element;
	}
	
	public static WebElement opt_Dashboards(WebDriver driver)
	{
		element = driver.findElement(By.id("userFunctions11.enabled1"));
		return element;
	}
	
	public static WebElement txtbx_Username(WebDriver driver)
	{
		element = driver.findElement(By.id("searchText"));
		return element;
	}
    
}
