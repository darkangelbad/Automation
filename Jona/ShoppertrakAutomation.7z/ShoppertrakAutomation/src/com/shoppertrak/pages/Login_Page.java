package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Login_Page 

{
	
	private static WebElement element = null;
	
	
	public static WebElement button_login(WebDriver driver)
	{
		element = driver.findElement(By.id("login_button"));
		return element;
	}
	

	public static WebElement txtbx_username(WebDriver driver)
	{
		element = driver.findElement(By.id("j_username"));
		return element;
	}
	

	public static WebElement txtbx_password(WebDriver driver)
	{
		element = driver.findElement(By.id("j_password"));
		return element;
	}
	

	public static WebElement forgot_password(WebDriver driver)
	{
		element = driver.findElement(By.id("forgot_password"));
		return element;
	}
}
