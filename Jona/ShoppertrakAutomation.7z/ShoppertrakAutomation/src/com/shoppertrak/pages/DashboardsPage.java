package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/*
# Dashboards Object
btn_SalesAndLabor=LinkText:Sales and Labor Process
btn_Logout=LinkText:Log Out
btn_Sites=LinkText:Sites
btn_Orgs=LinkText:Organizations
btn_Users=LinkText:Users
*/
 


public class DashboardsPage 

{
	
	private static WebElement element = null;
	
	
	public static WebElement btn_SalesAndLabor(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Sales and Labor Process"));
		return element;
	}
	
	public static WebElement btn_Logout(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Log Out"));
		return element;
	}
	
	public static WebElement btn_Sites(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Sites"));
		return element;
	}
	
	public static WebElement btn_Orgs(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Organizations"));
		return element;
	}
	
	public static WebElement btn_Users(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Users"));
		return element;
	}	
}