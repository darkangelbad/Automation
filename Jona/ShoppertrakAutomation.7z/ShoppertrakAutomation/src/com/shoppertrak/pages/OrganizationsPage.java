package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrganizationsPage {
    
    
	private static WebElement element = null;
	
	
	public static WebElement btn_OrgSave(WebDriver driver)
	{
		element = driver.findElement(By.id("submitButton"));
		return element;
	}	
	
	public static WebElement btn_OrgCancel(WebDriver driver)
	{
		element = driver.findElement(By.id("cancelButton"));
		return element;
	}	
	
	public static WebElement lbl_UpdateSucessful(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='flashParametersForm']/div[3]/div[1]/nobr"));
		return element;
	}	
	
	public static WebElement lst_DeliveryFrequency(WebDriver driver)
	{
		element = driver.findElement(By.xpath("frequency"));
		return element;
	}

	public static WebElement btn_Go(WebDriver driver)
	{
		element = driver.findElement(By.id("searchByIdButton"));
		return element;
	}
	

	public static WebElement btn_Logout(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Log Out"));
		return element;
	}
	

	public static WebElement btn_Sites(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Sites"));
		return element;
	}
	
	public static WebElement btn_Dash(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Dashboards"));
		return element;
	}
	
	public static WebElement btn_Users(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Users"));
		return element;
	}
	
	public static WebElement lst_Orgs(WebDriver driver)
	{
		element = driver.findElement(By.id("orgSelect"));
		return element;
	}
        
	public static WebElement btn_FlashTrafficDataFileGenerator(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='flashParametersForm']/div/div[2]/table/tbody/tr[1]/td[1]/div/a"));
		return element;
	}
}
