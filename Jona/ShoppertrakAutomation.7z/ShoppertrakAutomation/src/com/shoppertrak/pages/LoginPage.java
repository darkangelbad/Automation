package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
/*	
	public By usernameLocator = By.name("j_username");
	public By passwordLocator = By.name("j_password");
	public By loginButtonLocator = By.id("login_button");
	public By forgetPasswordLinkLocator = By.id("forgot_password");
	
	
	public void loginWithUsernamAndPassword(String username,String password, WebDriver driver){
		
		driver.findElement(usernameLocator).sendKeys(username);
		driver.findElement(passwordLocator).sendKeys(password);
		driver.findElement(loginButtonLocator).click();
    }
*/
    
    
	private static WebElement element = null;
	
	
	public static WebElement button_login(WebDriver driver)
	{
		element = driver.findElement(By.id("login_button"));
		return element;
	}
	

	public static WebElement txtbx_username(WebDriver driver)
	{
		element = driver.findElement(By.name("j_username"));
		return element;
	}
	

	public static WebElement txtbx_password(WebDriver driver)
	{
		element = driver.findElement(By.name("j_password"));
		return element;
	}
	

	public static WebElement forgot_password(WebDriver driver)
	{
		element = driver.findElement(By.id("forgot_password"));
		return element;
	}
    
}

