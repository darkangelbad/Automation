package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



/*
# Zones Object
lbl_ZoneValue=Xpath:.//*[@id='siteDetails']/div[3]/div[1]/span[2]
lbl_ZoneIdValue=Xpath:.//*[@id='siteDetails']/div[3]/div[1]/span[4]
lbl_EffectiveDateValue=Xpath:.//*[@id='siteDetails']/div[3]/div[1]/span[6]
lbl_TmpOneValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[2]
lbl_TmpIdValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[4]
lbl_TmpEffectiveDateValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[6]
lbl_zDeviceName=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[1]/div[1]
lbl_zDeviceType=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[1]/div[2]
lbl_zDeviceId=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[1]/span[1]
lbl_ZOrbitNumber=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[2]/span[1]
lbl_ZOrbitNumberValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[2]/span[2]
lbl_ZSerialNumber=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[2]/span[1]
lbl_ZSerialNumberValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[2]/span[2]
lbl_ZLastDataRec=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[3]/span[1]
lbl_ZLastDataRecValue=Xpath:.//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[3]/span[2]

*/

public class ZonesPages {

    	private static WebElement element = null;
	
	
	public static WebElement lbl_ZoneValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[1]/span[2]"));
		return element;
	}
	
	public static WebElement lbl_ZoneIdValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[1]/span[4]"));
		return element;
	}
	
	public static WebElement lbl_EffectiveDateValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[1]/span[6]"));
		return element;
	}
	
	public static WebElement lbl_TmpOneValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[2]"));
		return element;
	}
	
	public static WebElement lbl_TmpIdValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[4]"));
		return element;
	}
	
	public static WebElement lbl_TmpEffectiveDateValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[1]/span[6]"));
		return element;
	}
	
	public static WebElement lbl_zDeviceName(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[1]/div[1]"));
		return element;
	}
	
	public static WebElement lbl_zDeviceType(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[1]/div[2]"));
		return element;
	}
	
	public static WebElement lbl_zDeviceId(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[1]/span[1]"));
		return element;
	}
	
	public static WebElement lbl_ZOrbitNumber(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[2]/span[1]"));
		return element;
	}
	
	public static WebElement lbl_ZOrbitNumberValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[1]/div[2]/span[2]"));
		return element;
	}
	
	public static WebElement lbl_ZSerialNumber(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[2]/span[1]"));
		return element;
	}
	
	public static WebElement lbl_ZSerialNumberValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[2]/span[2]"));
		return element;
	}
	
	public static WebElement lbl_ZLastDataRec(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[3]/span[1]"));
		return element;
	}
	
	public static WebElement lbl_ZLastDataRecValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[3]/div[2]/div[2]/div[2]/div[3]/span[2]"));
		return element;
	}
    
}
