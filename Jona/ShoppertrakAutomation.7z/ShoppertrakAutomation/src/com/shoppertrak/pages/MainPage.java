package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



public class MainPage 

{
	
	private static WebElement element = null;
	
	
	public static WebElement btn_Logout(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Log Out"));
		return element;
	}
	
	public static WebElement btn_Org(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Organizations"));
		return element;
	}
	
	public static WebElement btn_Dash(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Dashboards"));
		return element;
	}
	
	public static WebElement btn_Users(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Users"));
		return element;
	}
	
	public static WebElement btn_Go(WebDriver driver)
	{
		element = driver.findElement(By.id("searchByIdButton"));
		return element;
	}
	
	public static WebElement btn_Search(WebDriver driver)
	{
		element = driver.findElement(By.id("searchByTextButton"));
		return element;
	}
	
	public static WebElement chk_SiteName(WebDriver driver)
	{
		element = driver.findElement(By.id("searchBySiteNameCheckbox"));
		return element;
	}
	
	public static WebElement chk_CustomerId(WebDriver driver)
	{
		element = driver.findElement(By.id(""));
		return element;
	}
	
	public static WebElement lst_Orgs(WebDriver driver)
	{
		element = driver.findElement(By.id("orgSelect"));
		return element;
	}
	
	public static WebElement opt_SiteId(WebDriver driver)
	{
		element = driver.findElement(By.id("siteButton"));
		return element;
	}
	
	public static WebElement opt_DeviceId(WebDriver driver)
	{
		element = driver.findElement(By.id("deviceButton"));
		return element;
	}
	
	public static WebElement txtbx_SearchId(WebDriver driver)
	{
		element = driver.findElement(By.id("idSearch"));
		return element;
	}
	
	public static WebElement txtbx_SearchOrg(WebDriver driver)
	{
		element = driver.findElement(By.id("textSearch"));
		return element;
	}
}
