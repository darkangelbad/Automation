package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SitesPage {
    
/*
# Site Actions Object
btn_InStoreFlashTraffic=LinkText:Update Flash Traffic Data File Generator Parameters
btn_RealTimeActivate=Id:activateEft
btn_RealTimeDeactivate=Id:deactivateEft
btn_AuthorizeRegistration=Id:authorizeRegistration
btn_RetrieveTraffic=Id:button_process_all
btn_Update=Id:updateTimezone
btn_LookupTimeZone=Id:lookupTimezone
lbl_AuthorizeRegistration=Xpath:.//*[@id='siteDetails']/div[3]/div/div[7]/form/span
lbl_RealTimeFlashTraffic=Xpath:.//*[@id='siteDetails']/div[3]/div/div[5]/div[1]/b
lbl_RealTimeFlashTrafficValue=Xpath:.//*[@id='siteDetails']/div[3]/div/div[5]/div[2]
lst_LookupTimeZone=Id:timezone
*/
    
    	private static WebElement element = null;
	
	
	public static WebElement btn_InStoreFlashTraffic(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Update Flash Traffic Data File Generator Parameters"));
		return element;
	}
	
	public static WebElement btn_RealTimeActivate(WebDriver driver)
	{
		element = driver.findElement(By.id("activateEft"));
		return element;
	}
	
	public static WebElement btn_RealTimeDeactivate(WebDriver driver)
	{
		element = driver.findElement(By.id("deactivateEft"));
		return element;
	}
	
	public static WebElement btn_AuthorizeRegistration(WebDriver driver)
	{
		element = driver.findElement(By.id("authorizeRegistration"));
		return element;
	}
	
	public static WebElement btn_RetrieveTraffic(WebDriver driver)
	{
		element = driver.findElement(By.id("button_process_all"));
		return element;
	}
	
	public static WebElement btn_Update(WebDriver driver)
	{
		element = driver.findElement(By.id("updateTimezone"));
		return element;
	}
	
	public static WebElement btn_LookupTimeZone(WebDriver driver)
	{
		element = driver.findElement(By.id("lookupTimezone"));
		return element;
	}
	
	public static WebElement lbl_AuthorizeRegistration(WebDriver driver)
	{
		element = driver.findElement(By.xpath("/html/body/div[@class='mainSiteEquipment']/div[@id='siteDetails']/div[@class='tabOuter tabOuterWidth floatleftclear']/div[@class='tabBody tabBodyColor']/div[@class='actionListItem'][6]/form[@id='authorizeRegistrationForm']/span"));
		return element;
	}
	
	public static WebElement lbl_RealTimeFlashTraffic(WebDriver driver)
	{
		element = driver.findElement(By.xpath("/*[@id='siteDetails']/div[3]/div/div[5]/div[1]/b"));
		return element;
	}
	
	public static WebElement lbl_RealTimeFlashTrafficValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("/*[@id='siteDetails']/div[3]/div/div[5]/div[2]"));
		return element;
	}
	
	public static WebElement lst_LookupTimeZone(WebDriver driver)
	{
		element = driver.findElement(By.id("timezone"));
		return element;
	}

}
