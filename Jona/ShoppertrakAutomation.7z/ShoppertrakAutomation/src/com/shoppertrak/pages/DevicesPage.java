
package com.shoppertrak.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.shoppertrak.resources.bean;


public class DevicesPage {
    
        	private static WebElement element = null;
	
	
	public static WebElement btn_Home(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Home"));
		return element;
	}
	
	public static WebElement btn_LogOut(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Log Out"));
		return element;
	}
	
	public static WebElement btn_Refresh(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Refresh"));
		return element;
	}
	
	public static WebElement btn_HideSiteInfo(WebDriver driver)
	{
		element = driver.findElement(By.id("hideDetailsLink"));
		return element;
	}
	
	public static WebElement btn_Zones(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Zones"));
		return element;
	}
	
	public static WebElement btn_SiteActions(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Site Actions"));
		return element;
	}
	
	public static WebElement btn_Video(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Video"));
		return element;
	}
	
	public static WebElement btn_DataManager(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Data Manager"));
		return element;
	}
	
	public static WebElement btn_SiteCommunication(WebDriver driver)
	{
		element = driver.findElement(By.linkText("Site Communication"));
		return element;
	}
	
	public static WebElement btn_Reset(WebDriver driver)
	{
		element = driver.findElement(By.id("ST600HardResetButton"));
		return element;
	}
	
	public static WebElement btn_Status(WebDriver driver)
	{
		element = driver.findElement(By.id("deviceStatusCheckButton"));
		return element;
	}
	
	public static WebElement btn_Options(WebDriver driver)
	{
		element = driver.findElement(By.id("options_link_+uniqueOrbitId"));
		return element;
	}
	
	public static WebElement btn_InitiateConfig(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div[1]/button[1]"));
		return element;
	}
	
	public static WebElement btn_AnalyzeScene(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div[1]/button[2]"));
		return element;
	}
	
	public static WebElement btn_SIPSyncClock(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div/button[1]"));
		return element;
	}
	
	public static WebElement btn_SyncClock(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='button_+uniqueOrbitId+']"));
		return element;
	}
	
	public static WebElement btn_SIPGetTime(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div/button[2]"));
		return element;
	}
	
	public static WebElement btn_GetTime(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='button_+uniqueOrbitId+'][2]"));
		return element;
	}
	
	public static WebElement btn_SIPClockReset(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div/button[3]"));
		return element;
	}
	
	public static WebElement btn_ClockReset(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='content_loading_+uniqueOrbitId+']/div[6]/div[1]/div[2]/button[3]"));
		return element;
	}
	
	public static WebElement btn_CalibZoneConfig(WebDriver driver)
	{
		element = driver.findElement(By.id("config_panel_+uniqueOrbitId"));
		return element;
	}
	
	public static WebElement btn_CalandZone(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-1']/form/div[1]/div[2]/div/input[1]"));
		return element;
	}
	
	public static WebElement btn_CalCopy(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-1']/form/div[1]/div[2]/div/input[2]"));
		return element;
	}
	
	public static WebElement btn_CalDelete(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-1']/form/div[1]/div[2]/div/input[3]"));
		return element;
	}
	
	public static WebElement btn_CalSend(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-1']/form/div[1]/div[2]/div/button"));
		return element;
	}
	
	public static WebElement btn_CalRetrieve(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-1']/form/div[2]/div[2]/div/input"));
		return element;
	}
	
	public static WebElement btn_Snapshots(WebDriver driver)
	{
		element = driver.findElement(By.xpath("(//button[@type='button'])[16]"));
		return element;
	}
	//ESTE ID ESTA REPETIDO
	public static WebElement btn_SnapshotsAndRecordings(WebDriver driver)
	{
		element = driver.findElement(By.id("ui-id-2"));
		return element;
	}
	
	public static WebElement btn_SnapView(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[1]/div[2]/div/input[1]"));
		return element;
	}
	
	public static WebElement btn_SnapDeleteOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[1]/div[2]/div/input[2]"));
		return element;
	}
	
	public static WebElement btn_SnapRetrieve(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[2]/div[2]/div/input[1]"));
		return element;
	}
	
	public static WebElement btn_SnapDeleteTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[2]/div[2]/div/input[2]"));
		return element;
	}
	
	public static WebElement btn_SnapDeleteThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[3]/div[2]/div/input"));
		return element;
	}
	
	public static WebElement btn_SnapshotOptions(WebDriver driver)
	{
		element = driver.findElement(By.id("snapshotOptionLink_+uniqueOrbitId"));
		return element;
	}
	
	public static WebElement btn_SnapCalendar(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='snapshot_calendar_display']/img"));
		return element;
	}
	
	public static WebElement btn_SnapCalendarNext(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/a[2]/span"));
		return element;
	}
	
	public static WebElement btn_SnapCalendarDayOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[1]/a"));
		return element;
	}
	
	public static WebElement btn_SnapCalendarDayTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[2]/a"));
		return element;
	}
	
	public static WebElement btn_SnapCalendarDayThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[3]/a"));
		return element;
	}
	
	public static WebElement btn_SnapTakeSnapshotSIP_VPN(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[4]/input"));
		return element;
	}
	
	public static WebElement btn_SnapTakeSnapshotSIPH_SSC(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-3']/div[5]/input"));
		return element;
	}
	
	public static WebElement btn_Recordings(WebDriver driver)
	{
		element = driver.findElement(By.id("ui-id-4"));
		return element;
	}
	
	public static WebElement btn_RecView(WebDriver driver)
	{
		element = driver.findElement(By.id("button_view_video_+uniqueOrbitId"));
		return element;
	}
	
	public static WebElement btn_RecDeleteOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-5']/div[1]/div[2]/div/input[2]"));
		return element;
	}
	
	public static WebElement btn_RecRetrieve(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-5']/div[2]/div[2]/div/input[1]"));
		return element;
	}
	
	public static WebElement btn_RecDeleteTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-5']/div[2]/div[2]/div/input[2]"));
		return element;
	}
	
	public static WebElement btn_RecDeleteThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-5']/div[3]/div[2]/div/input"));
		return element;
	}
	
	public static WebElement btn_RecDVROptions(WebDriver driver)
	{
		element = driver.findElement(By.id("dvrOptionLink_+uniqueOrbitId"));
		return element;
	}
	
	public static WebElement btn_RecCalendar(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='dvr_calendar_display']/img"));
		return element;
	}
	
	public static WebElement btn_RecCalendarNext(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[1]/a[2]/span"));
		return element;
	}
	
	public static WebElement btn_RecCalendarDayOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[1]/a"));
		return element;
	}
	
	public static WebElement btn_RecCalendarDayTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[2]/td[2]/a"));
		return element;
	}
	
	public static WebElement btn_RecScheduleDVR(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-id-5']/div[5]/input"));
		return element;
	}
	
	public static WebElement btn_TrafficOnDevice(WebDriver driver)
	{
		element = driver.findElement(By.id("ui-id-6"));
		return element;
	}	
        
        public static WebElement btn_TrafViewOptions(WebDriver driver)
	{
		element = driver.findElement(By.id("showViewOptions_+uniqueOrbitId"));
		return element;
	}	
        
        public static WebElement btn_TrafViewCalendar(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='viewTraffic_+uniqueOrbitId+']/div[1]/img"));
		return element;
	}	
        
        public static WebElement btn_TrafViewCalendarPreviou(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div/a[1]/span"));
		return element;
	}	
        
        public static WebElement btn_TrafViewCalendarPastDate(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]/a"));
		return element;
	}	
        
        public static WebElement btn_TrafViewTraffic(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]/a"));
		return element;
	}	
        
        public static WebElement btn_TrafProcessOptions(WebDriver driver)
	{
		element = driver.findElement(By.id("showProcessOptions_+uniqueOrbitId"));
		return element;
	}	
        
        public static WebElement btn_TrafProcessCalendarStart(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='processTraffic_+uniqueOrbitId+']/div[1]/img[1]"));
		return element;
	}	
        
        public static WebElement btn_TrafProcessCalendarEnd(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='processTraffic_+uniqueOrbitId+']/div[1]/img[2]"));
		return element;
	}	
        
        public static WebElement btn_TrafProcessTraffic(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='processTraffic_+uniqueOrbitId+']/div[2]/input"));
		return element;
	}	
        
        public static WebElement btn_Program(WebDriver driver)
	{
		element = driver.findElement(By.id("ui-id-8"));
		return element;
	}
        
        public static WebElement lbl_SiteValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteHeader']/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_OpenCaseValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteHeader']/div[1]/span[4]"));
		return element;
	}
        
        public static WebElement lbl_Device(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[1]/th[1]"));
		return element;
	}
        
        public static WebElement lbl_Count(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[1]/th[2]"));
		return element;
	}
        
        public static WebElement lbl_RowOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[2]/td[1]"));
		return element;
	}
        
        public static WebElement lbl_RowOneValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[2]/td[2]"));
		return element;
	}
        
        public static WebElement lbl_RowTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[3]/td[1]"));
		return element;
	}
        
        public static WebElement lbl_RowTwoValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[3]/td[2]"));
		return element;
	}
        
        public static WebElement lbl_RowThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[4]/td[1]"));
		return element;
	}
        
        public static WebElement lbl_RowThreeValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[4]/td[2]"));
		return element;
	}
        
        public static WebElement lbl_RowFour(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[5]/td[1]"));
		return element;
	}
        
        public static WebElement lbl_RowFourValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[1]/table/tbody/tr[5]/td[2]"));
		return element;
	}
        
        public static WebElement lbl_OrgValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[1]/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_CustomerIdValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[1]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_IdValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[1]/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_CommunicationValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[2]/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_SiteTypeValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[3]/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_TimeZoneValue(WebDriver driver)
	{
		element = driver.findElement(By.id("timezoneDisplay"));
		return element;
	}
        
        public static WebElement lbl_LastDataReleasedValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[3]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_RemedyStatusValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[1]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_InStoreFlashValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[2]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_RealTimeFlashValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[3]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_TrafficWatchValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[3]/div[1]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_RegistrationStatusValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("/html/body/div[@class='mainSiteEquipment']/div[@id='siteDetails']/div[@id='siteInfo']/div[@class='leftSiteInfoBlock']/div[@class='siteInfoBulk']/div[@class='goLeft'][2]/div[@class='siteInfoLargeLine'][1]/div[@class='lastDateInfoField']/span[@class='siteData']"));
		return element;
	}
        
        public static WebElement lbl_LastCheckinValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[2]/div[3]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_LastAuthenticatedCheckinValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteInfo']/div/div[2]/div[2]/div[3]/div[3]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_Lead(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[1]/div[1]/div[2]"));
		return element;
	}
        
        public static WebElement lbl_OrbitTypeValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[^createDiv^]/div[1]/div[2]/div"));
		return element;
	}
        
        public static WebElement lbl_St600Mac(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[1]/div[2]/div/div/span[2]"));
		return element;
	}
        
        public static WebElement lbl_OrbitMacOrSerial(WebDriver driver)
	{
		element = driver.findElement(By.id("deviceSerialNumber_+uniqueOrbitId"));
		return element;
	}
        
        public static WebElement lbl_MacAddress(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[1]/div[2]/div/div/span[1]"));
		return element;
	}
        
        public static WebElement lbl_MacAddressValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[1]/div[2]/div/div/span[2]"));
		return element;
	}
        
        public static WebElement lbl_IpAddress(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[1]/div[3]/div/div/span[1]"));
		return element;
	}
        
        public static WebElement lbl_IpAddressValue(WebDriver driver)
	{
		element = driver.findElement(By.id("leadDeviceIPAddress"));
		return element;
	}
        
        public static WebElement lbl_DeviceId(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[2]/div[2]/div[1]/div[1]/span[1]"));
		return element;
	}
        
        public static WebElement lbl_DeviceIdValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[^createDiv^]/div[2]/div[1]/div[1]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_OrbitNumber(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[2]/div[2]/div[1]/div[2]/span[1]"));
		return element;
	}
        
        public static WebElement lbl_OrbitNumberValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[^createDiv^]/div[2]/div[1]/div[2]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_SerialNumber(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[2]/div[2]/div[2]/span[1]"));
		return element;
	}
        
        public static WebElement lbl_SerialNumberValue(WebDriver driver)
	{
		element = driver.findElement(By.id("deviceSerialNumber_+uniqueOrbitId"));
		return element;
	}
        
        public static WebElement lbl_LastDataReceived(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[2]/div[2]/div[3]/span[1]"));
		return element;
	}
        
        public static WebElement lbl_LastDataReceivedValue(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='siteDetails']/div[4]/div[^createDiv^]/div[2]/div[3]/span[2]"));
		return element;
	}
        
        public static WebElement lbl_StatusContent(WebDriver driver)
	{
		element = driver.findElement(By.id("status_content_+uniqueOrbitId"));
		return element;
	}
        
        public static WebElement lbl_SnapshotsOnNetworkOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='snapshot_network_files_+uniqueOrbitId+']/option[1]"));
		return element;
	}
        
        public static WebElement lbl_SnapshotsOnNetworkTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='snapshot_network_files_+uniqueOrbitId+']/option[2]"));
		return element;
	}
        
        public static WebElement lbl_SnapshotsOnNetworkThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='snapshot_network_files_+uniqueOrbitId+']/option[3]"));
		return element;
	}
        
        public static WebElement lbl_RecordingsOnNetworkOne(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='dvr_network_files_+uniqueOrbitId+']/option[1]"));
		return element;
	}
        
        public static WebElement lbl_RecordingsOnNetworkTwo(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='dvr_network_files_+uniqueOrbitId+']/option[2]"));
		return element;
	}
        
        public static WebElement lbl_RecordingsOnNetworkThree(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id='dvr_network_files_+uniqueOrbitId+']/option[3]"));
		return element;
	}
        
        public static WebElement lbl_CurrentSystemImg(WebDriver driver)
	{
		element = driver.findElement(By.id("version_sys_+uniqueOrbitId"));
		return element;
	}
        
        public static WebElement lbl_CurrentExecutableValue(WebDriver driver)
	{
		element = driver.findElement(By.id("version_+uniqueOrbitId"));
		return element;
	}
        public static WebElement btn_ShowOptionsOrbit1(WebDriver driver)
        {
        	element = driver.findElement(By.id(DevicesPage.element_DeviceId(driver)));
        	return element;
        }
        
        public static WebElement btn_InitConfigOrbit1(WebDriver driver)
        {
        	String deviceId;
        	deviceId = driver.findElement(By.xpath("//div[@id='siteDetails']/div[4]/div[2]/div[2]/div/div/span[2]")).getText();
        	
        	//element = driver.findElement(By.xpath("//button[@onclick=\"app.newConfiguration('5418', '"+bean.getSiteId()+"', '"+deviceId+"', 'EP 01', 'Orbit5A');\"]"));
        	element = driver.findElement(By.xpath("//button[@onclick=\"app.newConfiguration('5418', '76124', '148373', 'EP 01', 'Orbit5A');\"]"));

        	// '5418', '76124', '148373', 'EP 01', 'Orbit5A'
        	return element;
        }
        
        public static String lbl_statusContentId(WebDriver driver)
        {
        	String lbl_statusContentId;
        	lbl_statusContentId = driver.findElement(By.xpath("//div[@id='siteDetails']/div[4]/div[2]/div[2]/div/div/span[2]")).getText();
        	return "status_content"+lbl_statusContentId;
        }
        
        public static WebElement box_Template(WebDriver driver)
        {
        	element = driver.findElement(By.cssSelector("select.templates"));
        	return element;
        }
        
        public static WebElement element_snapshot(WebElement driver)
        {
        	element = driver.findElement(By.xpath("/html/body/div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-front ui-dialog-buttons ui-draggable'][2]/div[@id='orbit_conf_dialog_148373']/div/div[@class='tabs-nohdr ui-tabs ui-widget ui-widget-content ui-corner-all']/div[@id='rawPanel_148373']/svg[@class='[object SVGAnimatedString]']/image[@id='image_0']"));
        	return element;

        }
        
        public static String element_DeviceId(WebDriver driver)
        {
        	String deviceId;
        	deviceId = driver.findElement(By.xpath("//div[@id='siteDetails']/div[4]/div[2]/div[2]/div/div/span[2]")).getText();
        	return "options_link_"+deviceId;
        }
     

        
        public static WebElement btn_CalculateHeights(WebDriver driver)
        {
        	element = driver.findElement(By.xpath("//body/ul/li[3]/span"));
        	return element;
        }
        
        public static WebElement cmb_MinSADDelta(WebDriver driver)
	{
		element = driver.findElement(By.id("minSADDelta"));
		return element;
	}
        
        public static WebElement cmb_MaxSADDist(WebDriver driver)
	{
		element = driver.findElement(By.id("maxSADDist"));
		return element;
	}
        
        public static WebElement cmb_MinDisparities(WebDriver driver)
	{
		element = driver.findElement(By.id("minDisparities"));
		return element;
	}
        
        public static WebElement cmb_FrameRate(WebDriver driver)
	{
		element = driver.findElement(By.id("FrameRate"));
		return element;
	}
        
        public static WebElement cmb_SyncSlaveSensor(WebDriver driver)
	{
		element = driver.findElement(By.id("SyncSlaveSensor"));
		return element;
	}
        
        public static WebElement cmb_NonLinearResponse(WebDriver driver)
	{
		element = driver.findElement(By.id("NonLinearResponse"));
		return element;
	}
      

        
        
        

    
}
