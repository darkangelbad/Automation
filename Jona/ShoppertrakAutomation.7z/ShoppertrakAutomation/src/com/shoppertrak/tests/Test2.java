package com.shoppertrak.tests;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.shoppertrak.pages.DevicesPage;
import com.shoppertrak.pages.LoginPage;
import com.shoppertrak.pages.MainPage;
import com.shoppertrak.resources.bean;





public class Test2 {

	public static void main(String[] args) throws InterruptedException {

	
		System.setProperty("webdriver.chrome.driver", bean.chromeDriverPath());
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		Actions action= new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, 2000);
		
		
		//Login	
		driver.get(bean.getBaseUrl());
		sleep(bean.getSmallTime());
		LoginPage.txtbx_username(driver).sendKeys(bean.getUser());
		LoginPage.txtbx_password(driver).sendKeys(bean.getPassword());
		LoginPage.button_login(driver).click();
		sleep(bean.getSmallTime());	
		//Search test Site ID
		MainPage.txtbx_SearchId(driver).sendKeys(bean.getSiteId());
		MainPage.btn_Go(driver).click();	
		sleep(bean.getSmallTime());
		
		//Test Case
		
		//On Orbit 01, Click on Show Options, then click Initiate Configuration.
		DevicesPage.btn_ShowOptionsOrbit1(driver).click();
		sleep(bean.getLongTime());
		DevicesPage.btn_InitConfigOrbit1(driver).click(); //This step maybe dinamically generated depending on Sets, TRY LATER
		sleep(bean.getSmallTime());
		//Verify the Template is correct. (select Payless template)
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id="status_content_148373"]")));
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("select.templates")));
		
	
		new Select(driver.findElement(By.cssSelector("select.templates"))).selectByVisibleText("Payless (IP) (primary)");
		
		//Click Take Snapshot  
		wait.until(ExpectedConditions.elementToBeClickable(DevicesPage.btn_Snapshots(driver)));
		DevicesPage.btn_Snapshots(driver).click();
		  
		//On the Calibration tab, right-click and select Calculate Height and click on the ends of 3-foot strip to calculate height.
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("image_0")));
		WebElement snapShot = driver.findElement(By.id("image_0"));
		System.out.println(driver.getTitle());
		sleep(bean.getSmallTime());
		Actions actions = new Actions(driver);
		System.out.println(driver.getTitle());
		actions.contextClick(snapShot).moveByOffset(200, 200).build().perform();
		
		//select Calculate Height and click on the ends of 3-foot strip to calculate height.
		DevicesPage.btn_CalculateHeights(driver).click();
		actions.click(snapShot).moveByOffset(50, 50).click().build().perform();
		sleep(bean.getSmallTime());

		//Save Height
		String savedHeight = driver.findElement(By.xpath("//*[@id='ui-id-21']/p")).getText().substring(8, 10) +" (default)";
		System.out.println(savedHeight);
		
		
		
		
		//Click Apply button
		sleep(bean.getSmallTime()); //quizas innecesario
		WebElement btn_Apply = driver.findElement(By.xpath("/html/body/div[10]/div[3]/div/button[1]"));
		actions.click(btn_Apply).perform();
		sleep(bean.getSmallTime());
		driver.findElement(By.xpath("/html/body/div[10]/div[3]/div/button")).click();
		
		//verify that the value is displayed in the Parameters tab: CameraHeight
		sleep(bean.getSmallTime());
		driver.findElement(By.xpath("//*[@id='orbit_conf_dialog_148373']/div/div/ul/li[4]")).click();
		sleep(bean.getSmallTime());
		String selectedOption = new Select(driver.findElement(By.id("CameraHeight"))).getFirstSelectedOption().getText();
		System.out.println(selectedOption);
		Assert.assertEquals(savedHeight, selectedOption); //hacer que continue
		
		//Calibration tab, right-click and select Zoning> Add Green Zone
		driver.findElement(By.xpath("//*[@id='orbit_conf_dialog_148373']/div/div/ul/li[1]")).click();
		sleep(bean.getSmallTime());
		actions.contextClick(driver.findElement(By.id("image_3"))).moveByOffset(200, 200).build().perform();
		driver.findElement(By.xpath("/html/body/ul[1]/li[1]")).click();
		driver.findElement(By.xpath("/html/body/ul[1]/li[1]/ul/li[2]")).click();
		sleep(bean.getSmallTime());
		actions.contextClick(driver.findElement(By.xpath("//*[@id='path_4']"))).moveByOffset(200, 200).build().perform();
		sleep(bean.getSmallTime());
		driver.findElement(By.xpath("/html/body/ul[3]/li[6]")).click();
		
		//Save shown values.
		sleep(bean.getSmallTime());
		String rightRowDelta = driver.findElement(By.xpath("//*[@id='ui-id-25']")).getText().substring(15, 18); 
		System.out.println(rightRowDelta);
		String rightColumnDelta = driver.findElement(By.xpath("//*[@id='ui-id-25']")).getText().substring(37, 40); 
		System.out.println(rightColumnDelta);
		
		
		//Click Apply button on the success dialog and verify that the values are displayed in the Parameters tab.
		driver.findElement(By.xpath("/html/body/div[10]/div[3]/div/button[1]")).click();
		
		
		//On the Parameters tab change the editable parameters "minSADDelta" ,"maxSADDist", minDisparities,
		// "FrameRate", "SyncSlaveSensor" and "NonLinearResponse" to make sure they are not default values.
		sleep(bean.getSmallTime());
		driver.findElement(By.xpath("/html/body/div[10]/div[3]/div/button")).click();
		driver.findElement(By.xpath("//*[@id='orbit_conf_dialog_148373']/div/div/ul/li[4]")).click();
		sleep(bean.getSmallTime());
		DevicesPage.cmb_MinSADDelta(driver).sendKeys("20");
		//System.out.println("cmb_MinSADDelta");
		DevicesPage.cmb_MaxSADDist(driver).sendKeys("2");
		//System.out.println("cmb_MinSADDelta");
		DevicesPage.cmb_MinDisparities(driver).sendKeys("3");
		//System.out.println("cmb_MinDisparities");
		DevicesPage.cmb_FrameRate(driver).sendKeys("10");
		//System.out.println("cmb_FrameRate");
		DevicesPage.cmb_SyncSlaveSensor(driver).sendKeys("off");
		//System.out.println("cmb_SyncSlaveSensor");
		DevicesPage.cmb_NonLinearResponse(driver).sendKeys("on");
		//System.out.println("cmb_NonLinearResponse");
		
		//Verify that the config parameters look correct on the Parameters tab:
		

		//ConfigDate and ConfigTime should be marked as (template)
		String ConfigDate = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[11]/td[2]/div")).getText().substring(11, 21);
		System.out.println(ConfigDate);
		Assert.assertEquals(ConfigDate, "(template)");
		String ConfigTime = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[12]/td[2]/div")).getText().substring(9);
		System.out.println(ConfigTime);
		Assert.assertEquals(ConfigTime, "(template)");
		
		//DeviceNum and dst_* parameters should be marked as (ref data)
		String DeviceNum = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[16]/td[2]/div")).getText().substring(2);
		System.out.println(DeviceNum);
		Assert.assertEquals(DeviceNum, "(ref data)");

		String dst_Zone_Date_Off = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[17]/td[2]/div")).getText().substring(6);
		System.out.println(dst_Zone_Date_Off);
		Assert.assertEquals(dst_Zone_Date_Off, "(ref data)");

		String dst_Zone_Date_On = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[19]/td[2]/div")).getText().substring(6);
		System.out.println(dst_Zone_Date_On);
		Assert.assertEquals(dst_Zone_Date_On, "(ref data)");
	
		String dst_Zone_Time_Off = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[20]/td[2]/div")).getText().substring(6);
		System.out.println(dst_Zone_Time_Off);
		Assert.assertEquals(dst_Zone_Time_Off, "(ref data)");

		String dst_Zone_Time_On = driver.findElement(By.xpath("//*[@id='parametersPanel_148373']/div[2]/table/tbody/tr[21]/td[2]/div")).getText().substring(6);
		System.out.println(dst_Zone_Time_On);
		Assert.assertEquals(dst_Zone_Time_On, "(ref data)");
		
		//In Zoning tab draw a Green Zone and a Red Zone (or default zones)
		driver.findElement(By.xpath("//*[@id='orbit_conf_dialog_148373']/div/div/ul/li[2]")).click();
		sleep(bean.getSmallTime());
		actions.contextClick(driver.findElement(By.id("path_11"))).moveByOffset(-800, 0).build().perform();
		driver.findElement(By.xpath("/html/body/ul[3]/li[1]")).click();
		driver.findElement(By.xpath("/html/body/ul[3]/li[1]/ul/li[1]")).click();
		
		//Click Save & Send. You should receive a "Saved and Sent, rebooting the Orbit" message
		sleep(bean.getSmallTime());
		driver.findElement(By.xpath("/html/body/div[8]/div[3]/div/button[1]")).click();
		sleep(bean.getLongTime());		
		driver.findElement(By.xpath("/html/body/div[8]/div[3]/div/button")).click();
		
		
		Date cfgDateTime = new Date();
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
		format.setTimeZone(TimeZone.getTimeZone("CST"));
		String cfgDateTimeToStr = format.format(cfgDateTime);
		System.out.println(cfgDateTimeToStr);
		
		
		wait.until(ExpectedConditions.textToBePresentInElement(By.xpath("//*[@id='status_content_148373']"), "Command Successful!"));
		DevicesPage.btn_ShowOptionsOrbit1(driver).click();
		sleep(bean.getLongTime());
		driver.findElement(By.xpath("//*[@id='config_panel_148373']"));
		String lastCfgDateTime = driver.findElement(By.xpath("//*[@id='config_network_files_148373']/option[1]")).getAttribute("title").substring(31);
		System.out.println(lastCfgDateTime);
		Assert.assertEquals(lastCfgDateTime, cfgDateTimeToStr);

		
	}
	
	
	private static void sleep(int i) {
		
		try {
			Thread.sleep(i);
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		}
		
		
	}
	
	

}
