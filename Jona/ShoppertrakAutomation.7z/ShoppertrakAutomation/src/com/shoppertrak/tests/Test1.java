package com.shoppertrak.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.shoppertrak.pages.DevicesPage;
import com.shoppertrak.pages.LoginPage;
import com.shoppertrak.pages.MainPage;
import com.shoppertrak.pages.SitesPage;
import com.shoppertrak.resources.bean;

/*
1.Bring up an SSC site in Operations Portal
	a.If a connection to this site is already opened, wait 20 minutes for it to time out, or manually break the connection by power-cycling the lead ST600.
	b.If Last Checkin and Last Authenticated Checkin shows yesterday's date 11:05 PM site local time, EFT is probably turned on for this site and the site is connected.
2.Click on the Site Actions tab
3.Click Authorize Registration
4.Single Site Registration text will change to "This Device has been authorized to Register until hh:mm AM/PM Time Zone"
5.Registration Status will change to �Registration Authorized�
6.Within 5 minutes, Registration Status will change to �Registered�
7.Last Checkin and Last Authenticated Checkin will match after registration
*/

public class Test1 {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", bean.chromeDriverPath());
		WebDriver driver = new ChromeDriver();
		String registrationTime;
		String registrationAuthorization;
		String lastCheckInTime;
		String lastAuthCheckInTime;
		Date registrationDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("h:mm a z");
		String dateToStr = format.format(registrationDate);

		driver.get(bean.getBaseUrl());
		
		Thread.sleep(bean.getSmallTime());
		
		LoginPage.txtbx_username(driver).sendKeys(bean.getUser());
		LoginPage.txtbx_password(driver).sendKeys(bean.getPassword());
		LoginPage.button_login(driver).click();
		
		Thread.sleep(bean.getSmallTime());
		
		MainPage.txtbx_SearchId(driver).sendKeys(bean.getSiteId());
		MainPage.btn_Go(driver).click();
		DevicesPage.btn_SiteActions(driver).click();
		
		Thread.sleep(bean.getSmallTime());
		
		SitesPage.btn_AuthorizeRegistration(driver).click();
		registrationTime = (SitesPage.lbl_AuthorizeRegistration(driver).getText());
        try {
        	Assert.assertEquals("This Device has been authorized to Register until "+dateToStr+"", registrationTime);
            System.out.println("present");
        } catch (Error e) {
            System.out.println("Not present");
        }
        
        
		registrationAuthorization = (DevicesPage.lbl_RegistrationStatusValue(driver).getText());
        try {
        	Assert.assertEquals("Registration Authorized", registrationAuthorization);
            System.out.println("present");
        } catch (Error e) {
            System.out.println("not present");
        }
        
        lastCheckInTime = (DevicesPage.lbl_LastCheckinValue(driver).getText());
        lastAuthCheckInTime = (DevicesPage.lbl_LastAuthenticatedCheckinValue(driver).getText());
        try {
        	Assert.assertEquals(lastCheckInTime, lastAuthCheckInTime);
            System.out.println("present");
        } catch (Error e) {
            System.out.println("not present");
        }
        
      
	}
	private static void sleep(int i) {
		
		try {
			Thread.sleep(i);
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		}
		
		
	}
}
