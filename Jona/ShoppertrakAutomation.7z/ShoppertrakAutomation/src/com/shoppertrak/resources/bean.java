/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.shoppertrak.resources;

import java.beans.*;
import java.io.Serializable;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.seleniumhq.jetty9.util.log.Log;


public class bean implements Serializable {
    
	private static final String browser = ""; //Values: Chrome,IE, Firefox
    private static final String user = "enardi@shoppertrak.com";
    private static final String password = "passw0rd";
    private static final String baseurl = "http://operationsportal-test02.rctanalytics.com/operationsportal" + "/";
    private static final String siteId = "76124";
    private static final String chromeDriverPath = "C:/Users/ENARDI/automation-ui-tests/chromedriver.exe";
    private static final int smalltime = 3000;
    private static final int longtime = 10000;
    


    public static String browser() {
        return browser;
    }
    
    public static String getUser() {
        return user;
    }

    public static String getPassword() {
        return password;
    }

    public static String getBaseUrl() {
        return baseurl;
    }
    
    public static String getSiteId() {
        return siteId;
    }

    public static String chromeDriverPath() {
        return chromeDriverPath;
    }

    public static int getSmallTime() {
        return smalltime;
    }

    public static int getLongTime() {
        return longtime;
    }    
}


