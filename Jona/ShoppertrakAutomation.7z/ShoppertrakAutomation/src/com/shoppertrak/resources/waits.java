package com.shoppertrak.resources;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class waits {


	private static void sleep(int i) {
		
		try {
			Thread.sleep(i);
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		}
}
}
